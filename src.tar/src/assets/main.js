let timer;
let isRunning = false;
let timeRemaining = 25 * 60; // 25 minutes in seconds
const timerElement = document.getElementById('tempo-decorrido');
const startButton = document.getElementById('start');
const resetButton = document.getElementById('reset');
const increaseButton = document.getElementById('increase');
const decreaseButton = document.getElementById('decrease');

function updateTimerDisplay() {
  const minutes = Math.floor(timeRemaining / 60);
  const seconds = timeRemaining % 60;
  timerElement.textContent = `${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
}

function startTimer() {
  if (!isRunning) {
    isRunning = true;
    timer = setInterval(() => {
      if (timeRemaining > 0) {
        timeRemaining--;
        updateTimerDisplay();
      } else {
        clearInterval(timer);
        isRunning = false;
        alert("Pomodoro completed!");
      }
    }, 1000);
  }
}

function pauseTimer() {
  clearInterval(timer);
  isRunning = false;
}

function resetTimer() {
  pauseTimer();
  timeRemaining = 25 * 60;
  updateTimerDisplay();
}

function increaseTime() {
  if (!isRunning) {
    timeRemaining += 60;
    updateTimerDisplay();
  }
}

function decreaseTime() {
  if (!isRunning && timeRemaining > 60) {
    timeRemaining -= 60;
    updateTimerDisplay();
  }
}

startButton.addEventListener('click', () => {
  if (isRunning) {
    pauseTimer();
    startButton.textContent = "Start";
  } else {
    startTimer();
    startButton.textContent = "Pause";
  }
});

resetButton.addEventListener('click', resetTimer);
increaseButton.addEventListener('click', increaseTime);
decreaseButton.addEventListener('click', decreaseTime);

updateTimerDisplay();
